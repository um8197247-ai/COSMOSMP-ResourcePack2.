COSMOSMP TAB Logo Resource Pack

Minecraft Java 1.21.11

TAB header line (MiniMessage):
<font:cosmos:logo>\uE001</font>

If your YAML editor does not convert \uE001, copy the private-use character directly from this file's matching font mapping: U+E001.

Install this ZIP as a client resource pack for testing. For server-wide delivery, host this ZIP at a direct HTTPS download URL and set resource-pack and resource-pack-sha1 in server.properties (or the host's resource-pack settings). The pack does not need to be placed in the server's mods folder.
